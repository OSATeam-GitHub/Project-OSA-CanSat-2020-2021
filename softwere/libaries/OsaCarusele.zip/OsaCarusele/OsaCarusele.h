#ifndef OsaCarusele_h
#define OsaCarusele_h
#include "CanSatKit.h"
#include "Arduino.h"
#include "Adafruit_GPS.h"
#include "stdio.h"
#include "stdint.h"
using namespace CanSatKit;

class OsaCarusele
{
public:
  OsaCarusele();
  void begin();
  void backlashCorrection(bool blDirection);
  void takeSample(int index);
  void inject();
  void eject();
  void leaveRest();
  void rest();
  void makeRestStep();
  void autohome();
  void rotateStepper(float to_position);
  void makeStep(int xw);
  void SetDirection();
  void gpsCheck();
  void repidProbes();
  //nmea_float_t gpsCalcAltitude();
  bool probesDone[5];
  float samplesAltitudes[5][2];
  const int STEPUPPOWER = 0;
  int SERVOPOWER = 6;
  int servo_pin = 7;
  int IN1 = 2;
  int IN2 = 3;
  int IN3 = 4;
  int IN4 = 5;
  const int steps_per_rotation = 4096;
  int stepper_position; //obecna pozycja silnika
  bool Direction;
  int Steps;
  long t;
  unsigned long pumpCurrentMillis, pumpPreviousMillis;
  int pumpEnablePin = 9;
  int LIMITSWITCH = 1; //krańcówka
  bool Restdone;
  int restStep;
  const char parachutePin = A0;
  unsigned long currentMillis, previousMillis;
  //-------------------------measurments---------------------------------------
  bool isParachuteOpened();
  void ifIntervalSendMeasurments();
  nmea_float_t altiduteCalc();
  void takeAndTransmitMeasurments();
  void takeMeasurments();
  void measurementsFrameCreate();
  void radioFrameCreate();
  void measurementsFrameTransmit();
  void measurementsFrameFileWrite();
  void ream();
  void radioSendTekst(String tekst);
  void radioSendInt(int number);
  nmea_float_t initialAltitude, finalAltitude, currentAltitude, previousAltitude;
  const int ledPin = 13;
  String measurementsFileName = "TRANS_10.txt";
  int sdCardPin = 11;
  float ambientPressure;
  float ambientTemp;
  float ambientHumidity;
  float pipePressure;
  const float Psi2Pascal = 6894.75729F;
  uint8_t gpsHours;
  uint8_t gpsMinutes;
  uint8_t gpsSeconds;
  uint8_t gpsMillis;
  uint8_t gpsDay;
  uint8_t gpsMonth;
  uint8_t gpsYear;
  bool gpsFix;
  uint8_t gpsFixQuality;
  nmea_float_t gpsLatitude;
  char gpsLat;
  nmea_float_t gpsLongitude;
  char gpsLon;
  nmea_float_t gpsAltitude;
  uint8_t gpsSat;
  float groundPressure;
  float currentPressure;
  float currentTemp;
  const float airMolarMass = 0.0289644;
  const float standardGravity = 9.8105;
  const float gasConst = 8.31446261815324;
  float calcCurrentAltitude;
  float calcPreviousAltitude;
  uint32_t timer;
  const long measurementInterval = 1000; // interval at which to read sensor (milliseconds)
  unsigned long measurmentCurrentMillis, measurmentPreviousMillis;
  const long gpsInterval = 1;
  unsigned long gpsCurrentMillis, gpsPreviousMillis;
  uint8_t programFaze;

  bool ledState;
  //-------------encoder------------

   uint8_t bytes[100];
  uint8_t *ptr = bytes;
  uint8_t *encode_bytes(uint8_t *ptr, void *bytes, uint16_t size);
  uint8_t *decode_bytes(uint8_t *ptr, void *bytes, uint16_t size);
  uint8_t *encode_uint8(uint8_t *ptr, uint8_t value);
  uint8_t *encode_uint16(uint8_t *ptr, uint16_t value);
  uint8_t *encode_uint32(uint8_t *ptr, uint32_t value);
  uint8_t *encode_f32(uint8_t *ptr, float value);
  uint8_t *encode_char(uint8_t *ptr, char value);
  uint8_t *decode_uint8(uint8_t *ptr, uint8_t *value);
  uint8_t *decode_uint16(uint8_t *ptr, uint16_t *value);
  uint8_t *decode_uint32(uint8_t *ptr, uint32_t *value);
  uint8_t *decode_f32(uint8_t *ptr, float *value);
  uint8_t *decode_char(uint8_t *ptr, char *value);

private:
};

#endif
