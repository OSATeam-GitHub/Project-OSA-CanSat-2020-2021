#include "Arduino.h"
#include "OsaCarusele.h"
#include "Servo.h"
#include <CanSatKit.h>
#include <Wire.h>
#include <string.h>

using namespace CanSatKit;
Servo servo;
//OsaMeasurments osameasurments;
//---------measurments----------

// ---------------------- SD Card definitions -----------------------------
#include <SD.h>
File measurementsFile;

// ------------------------------------------------------------------------

// ---------------------- LoRa Radio definitions --------------------------
/*Radio radio(Pins::Radio::ChipSelect,
            Pins::Radio::DIO0,
            433.0,
            Bandwidth_125000_Hz,
            SpreadingFactor_8, //Optimal 9
            CodingRate_4_8);   //Optimal 4_8*/

// create (empty) radio frame object that can store data
// to be sent via radio
Frame measurementsFrame;
// ------------------------------------------------------------------------

// ---------------------- BME280 sensor definitions -----------------------
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>
Adafruit_BME280 bme; // I2C BME280 sensor declaration

// ------------------------------------------------------------------------

// ---------------------- Honeywell sensor definitions --------------------

#include <SSC.h>
    //create an SSC sensor with I2C address 0x28 and direct power line
//SSC ssc(0x28, 255);
//const float Psi2Pascal = 6894.75729F; //PSI to Pascal coefficient
// ------------------------------------------------------------------------

// ---------------------- GPS module definitions --------------------------
#include <Adafruit_GPS.h>
//#include <SoftwareSerial.h>                       //if software UART is used
//SoftwareSerial gpsSerial(8, 7);                   //Connect the GPS TX D8 and RX to D7
#define gpsSerial Serial //if hardware UART port is used
Adafruit_GPS GPS(&gpsSerial);
#define GPSECHO false

SSC ssc(0x28, 255);
Radio radio(Pins::Radio::ChipSelect,
            Pins::Radio::DIO0,
            433.3,
            Bandwidth_125000_Hz,
            SpreadingFactor_9, //Optimal 9
            CodingRate_4_8);   //Optimal 4_8

//-------------encoding--------------
/*#include "LoraMessage.h"
#include "LoraEncoder.h"
LoraMessage message;
byte buffer[4];
LoraEncoder encoder(buffer);
encoder.writeRawFloat(99.99);
//buffer == {0xe1, 0xfa, 0xc7, 0x42}
*/
#include "stdio.h"
#include "stdint.h"

OsaCarusele::OsaCarusele()
{
  stepper_position = 0; //obecna pozycja silnika
  Direction = true;
  Steps = 0;
  pumpCurrentMillis = 0;
  pumpPreviousMillis = 0;
  Restdone = false;
  restStep = 0;
  currentMillis = 0;
  previousMillis = 0;
  //sampleCurrentMillis = 0;
  //samplePreviousMillis = 0;
  // ------------------------------ Other -----------------------------------
  digitalWrite(ledPin, HIGH);

  pinMode(IN1, OUTPUT);
  digitalWrite(IN1, LOW); //ustawienie pinów silnika na wyjście
  pinMode(IN2, OUTPUT);
  digitalWrite(IN2, LOW);
  pinMode(IN3, OUTPUT);
  digitalWrite(IN3, LOW);
  pinMode(IN4, OUTPUT);
  digitalWrite(IN4, LOW);
  pinMode(LIMITSWITCH, INPUT);     //ustawienie krańcówki na wejście
  digitalWrite(LIMITSWITCH, HIGH); // podciągnięcie krańcówki do 5V

  pinMode(SERVOPOWER, OUTPUT); // ustawienie włączników zasilania na wyjście -> opcjonalne

  pinMode(pumpEnablePin, OUTPUT);
  digitalWrite(pumpEnablePin, LOW);

  pinMode(STEPUPPOWER, OUTPUT);
  digitalWrite(STEPUPPOWER, HIGH);

  servo.attach(servo_pin);
}

/*void OsaCarusele::radioSendTekst(String text)
{
  while (not radio.transmit(text))
  {
    radio.transmit(text);
  }
}

void OsaCarusele::radioSendInt(int number)
{
  String _number = (String)number;
  while (not radio.transmit(_number))
  {
    radio.transmit(_number);
  }
}*/

/*nmea_float_t gpsCalcAltitude()
{ 
  if (GPS.fixquality == 2)
  { 
    return GPS.altitude;
  }
  else
  { 
    return altiduteCalc();
  }
}*/

bool OsaCarusele::isParachuteOpened()
{
  return digitalRead(parachutePin);
}

void OsaCarusele::gpsCheck()
{
  char c = GPS.read();
  // if you want to debug, this is a good time to do it!
  //if ((c) && (GPSECHO))
  //  SerialUSB.write(c);

  // if a sentence is received, we can check the checksum, parse it...
  if (GPS.newNMEAreceived())
  {
    if (!GPS.parse(GPS.lastNMEA())) // this also sets the newNMEAreceived() flag to false
      return;                       // we can fail to parse a sentence in which case we should just wait for another
  }
}

void OsaCarusele::backlashCorrection(bool blDirection) //Przed zmianą kierunku wykanaj funkcję, aby zniwelować luzy
{
  digitalWrite(STEPUPPOWER, HIGH);
  if (blDirection == 1)
    Direction = HIGH;
  if (blDirection == 0)
    Direction = LOW;

  int steps_left = 3.5 * steps_per_rotation / 360; //kąt o jaki ma się przekręcić silnik *steps_per_rotation/360
                                                   //digitalWrite(STEPPERPOWER, HIGH);
  while (steps_left > 0)
  {
    ifIntervalSendMeasurments();
    currentMillis = micros();
    if (currentMillis - previousMillis >= 1000)
    {
      makeStep(1);
      t = t + micros() - previousMillis;
      previousMillis = micros();
      steps_left--;
    }
  }
}

void OsaCarusele::takeSample(int index)
{
  digitalWrite(STEPUPPOWER, HIGH);
  digitalWrite(SERVOPOWER, HIGH);
  servo.write(145);
  rotateStepper(45 * index);
  ream();
  samplesAltitudes[index][0] = altiduteCalc();
  inject();
  pumpPreviousMillis = millis();
  pumpCurrentMillis = pumpPreviousMillis;
  while (pipePressure < 150000 && pumpCurrentMillis - pumpPreviousMillis < 4000)
  {
    ifIntervalSendMeasurments();
    digitalWrite(pumpEnablePin, HIGH);
    ssc.update();
    pipePressure = ssc.pressure() * Psi2Pascal;
    pumpCurrentMillis = millis();
    if (pipePressure >= 150000)
    {
      probesDone[index] = 1;
      /*while (not radio.transmit("PP reached 145000 Pa "))
      {
        radio.transmit("PP reached 145000 Pa ");
      }*/
    }
  }
  digitalWrite(pumpEnablePin, LOW);
  eject();
  samplesAltitudes[index][1] = altiduteCalc();

  SerialUSB.print("needle was ejected ");
  SerialUSB.println(index + 1);

  digitalWrite(SERVOPOWER, LOW);
}

void OsaCarusele::repidProbes()
{
  bool anyNotDone = 0;
  for (int i = 0; i < 5; i++)
  {
    if (probesDone[i] == 0)
    {
      anyNotDone = 1;
    }
  }
  if (anyNotDone)
  {
    autohome();
    for (int i = 0; i < 5; i++)
    {
      if (probesDone[i] == 0)
      {
        takeSample(i);
      }
    }
  }
}

void OsaCarusele::ream()
{
  digitalWrite(STEPUPPOWER, HIGH);
  previousMillis = millis();
  currentMillis = previousMillis; 

  digitalWrite(pumpEnablePin, HIGH);
  while (currentMillis - previousMillis < 300)
  {
    currentMillis = millis();
    ifIntervalSendMeasurments();
  }
  digitalWrite(pumpEnablePin, LOW);
}

void OsaCarusele::inject()
{

  for (float a = 145; a > 55; a -= 0.001) //powoli wbija igłę
  {
    ifIntervalSendMeasurments();
    servo.write(a);
  }
}

void OsaCarusele::eject()
{
  for (float a = 55; a < 145; a += 0.0005) //powoli wyciąga igłę
  {
    ifIntervalSendMeasurments();
    servo.write(a);
  }
}

void OsaCarusele::leaveRest()
{
  digitalWrite(STEPUPPOWER, HIGH);
  digitalWrite(SERVOPOWER, HIGH);
  for (float a = 55; a < 145; a += 0.0005) //powoli wyciąga igłę
  {
    ifIntervalSendMeasurments();
    servo.write(a);
  }
  rotateStepper(-20);
  backlashCorrection(1);

  digitalWrite(SERVOPOWER, LOW);
}

void OsaCarusele::rest()
{
  digitalWrite(STEPUPPOWER, HIGH);
  digitalWrite(SERVOPOWER, HIGH);
  restStep = 0;
  servo.write(145);
  currentMillis = millis();
  Restdone = false;
  while (Restdone == false)
  {
    ifIntervalSendMeasurments();
    currentMillis = millis();

    if (currentMillis - previousMillis >= 300)
    {
      makeRestStep();
      previousMillis = millis();
    }
  }
  digitalWrite(SERVOPOWER, LOW);
  digitalWrite(STEPUPPOWER, LOW);
}

void OsaCarusele::makeRestStep()
{
  switch (restStep)
  {
  case 0:
    servo.write(145);
    break;

  case 1:
    rotateStepper(22);
    break;

  case 2:
    for (float a = 145; a > 55; a -= 0.0005) //powoli wbija igłę
    {
      ifIntervalSendMeasurments();
      servo.write(a);
    }

    Restdone = true;
    break;
  }
  restStep++;
}

void OsaCarusele::autohome() //dojeżdża do krańcówki
{
  digitalWrite(STEPUPPOWER, HIGH);
  digitalWrite(SERVOPOWER, HIGH);
  servo.write(145);

  Direction = false;
  while (digitalRead(LIMITSWITCH))
  {
    ifIntervalSendMeasurments();
    currentMillis = micros();

    if (currentMillis - previousMillis >= 1000)
    {
      makeStep(1);
      t = t + micros() - previousMillis;
      previousMillis = micros();
    }
  }
  backlashCorrection(1);
  stepper_position = -23; //-27
  //digitalWrite(SERVOPOWER, LOW);
}

void OsaCarusele::rotateStepper(float to_position) // obraca silnik do wybranej pozycji ( pozycja w której mogłaby wbić igłe do 1. probówki to pozycja 0, pozycje pozostałe to kąt od pozycji 0)
{
  Direction = HIGH;
  float angle = to_position - stepper_position;

  float temangle = angle;
  if (angle < 0)
  {
    Direction = LOW;
    temangle = -angle;
  }
  int steps_left = temangle * steps_per_rotation / 360;
  // digitalWrite(STEPPERPOWER, HIGH);
  digitalWrite(STEPUPPOWER, HIGH);
  while (steps_left > 0)
  {
    ifIntervalSendMeasurments();
    currentMillis = micros();

    if (currentMillis - previousMillis >= 1000)
    {
      makeStep(1);
      t = t + micros() - previousMillis;
      previousMillis = micros();
      steps_left--;
    }
  }

  stepper_position += angle;

  if (stepper_position >= 360)
    stepper_position -= 360;
}

void OsaCarusele::makeStep(int xw)
{
  for (int x = 0; x < xw; x++)
  {
    switch (Steps)
    {
    case 0:
      digitalWrite(IN1, LOW);
      digitalWrite(IN2, LOW);
      digitalWrite(IN3, LOW);
      digitalWrite(IN4, HIGH);
      break;
    case 1:
      digitalWrite(IN1, LOW);
      digitalWrite(IN2, LOW);
      digitalWrite(IN3, HIGH);
      digitalWrite(IN4, HIGH);
      break;
    case 2:
      digitalWrite(IN1, LOW);
      digitalWrite(IN2, LOW);
      digitalWrite(IN3, HIGH);
      digitalWrite(IN4, LOW);
      break;
    case 3:
      digitalWrite(IN1, LOW);
      digitalWrite(IN2, HIGH);
      digitalWrite(IN3, HIGH);
      digitalWrite(IN4, LOW);
      break;
    case 4:
      digitalWrite(IN1, LOW);
      digitalWrite(IN2, HIGH);
      digitalWrite(IN3, LOW);
      digitalWrite(IN4, LOW);
      break;
    case 5:
      digitalWrite(IN1, HIGH);
      digitalWrite(IN2, HIGH);
      digitalWrite(IN3, LOW);
      digitalWrite(IN4, LOW);
      break;
    case 6:
      digitalWrite(IN1, HIGH);
      digitalWrite(IN2, LOW);
      digitalWrite(IN3, LOW);
      digitalWrite(IN4, LOW);
      break;
    case 7:
      digitalWrite(IN1, HIGH);
      digitalWrite(IN2, LOW);
      digitalWrite(IN3, LOW);
      digitalWrite(IN4, HIGH);
      break;
    default:
      digitalWrite(IN1, LOW);
      digitalWrite(IN2, LOW);
      digitalWrite(IN3, LOW);
      digitalWrite(IN4, LOW);
      break;
    }
    SetDirection();
  }
}

void OsaCarusele::SetDirection()
{
  if (Direction == 0)
  {
    Steps++;
  }
  if (Direction == 1)
  {
    Steps--;
  }
  if (Steps > 7)
  {
    Steps = 0;
  }
  if (Steps < 0)
  {
    Steps = 7;
  }
}

//--------------measurments------------

void OsaCarusele::begin()
{
  ambientPressure = 0.0F;
  ambientTemp = 0.0F;
  ambientHumidity = 0.0F;

  pipePressure = 0.0F;

  groundPressure = 0.0F;
  currentPressure = 0.0F;
  currentTemp = 0.0F;
  calcCurrentAltitude = 0;
  calcPreviousAltitude = 0;
  timer = millis();
  measurmentCurrentMillis = 0;
  measurmentPreviousMillis = 0;
  ledState = false;
  pinMode(ledPin, OUTPUT);

  SerialUSB.begin(115200);
  SerialUSB.println("CanSat initialization starting...");

  while (!Serial)
    ; // time to get serial running
  Wire.begin();
  GPS.begin(9600);
  GPS.sendCommand(PMTK_SET_NMEA_OUTPUT_RMCGGA);
  GPS.sendCommand(PGCMD_ANTENNA);
  delay(1000);
  gpsSerial.println(PMTK_Q_RELEASE); // Ask for firmware version
  SerialUSB.println("the GPS library is started...");

  //set min and max reading and pressure values, see datasheet for eqn
  //------------------------------------------------------------------------------------------------------------------------------------------------------------------SSC
  ssc.setMinRaw(1638);    // output at minimum calibrated pressure (counts)
  ssc.setMaxRaw(14746);   //output at maximum calibrated pressure (counts)
  ssc.setMinPressure(0);  // min value of pressure range (ours 0-30 PSI gage)
  ssc.setMaxPressure(30); // max value of pressure range (ours 0-30 PSI gage)

  //start your SSC sensor
  ssc.start();

  SerialUSB.println("the SSC sensor is started...");

  //start your BME sensor
  unsigned status;
  status = bme.begin(0x76);
  if (!status)
  {
    SerialUSB.println("Could not find a valid BME280 sensor, check wiring, address, sensor ID!"); //zostawiłbym tą linijke tylko z ifa
    SerialUSB.print("SensorID was: 0x");
    SerialUSB.println(bme.sensorID(), 16);
    SerialUSB.print("        ID of 0xFF probably means a bad address, a BMP 180 or BMP 085\n");
    SerialUSB.print("   ID of 0x56-0x58 represents a BMP 280,\n");
    SerialUSB.print("        ID of 0x60 represents a BME 280.\n");
    SerialUSB.print("        ID of 0x61 represents a BME 680.\n");
    while (1)
      delay(10);
  }
  SerialUSB.println("the BME sensor is started...");

  if (!SD.begin(sdCardPin))
  {
    SerialUSB.println("the SD Card failed or not present");
    while (1)
    {
    }
  }
  SerialUSB.println("the SD card is started...");

  radio.begin();
  SerialUSB.println("the LoRa radio is started...");

  groundPressure = bme.readPressure();
  SerialUSB.println("Groud Pressure is: ");
  SerialUSB.print(groundPressure);

  pinMode(parachutePin, INPUT);
  digitalWrite(parachutePin, HIGH);
 // programFaze = 0;
}

void OsaCarusele::ifIntervalSendMeasurments()
{
  gpsCurrentMillis = millis();
  if(gpsCurrentMillis - gpsPreviousMillis >= gpsInterval)
  { 
    gpsPreviousMillis = gpsCurrentMillis;
    gpsCheck();
  }
  measurmentCurrentMillis = millis();
  if (measurmentCurrentMillis - measurmentPreviousMillis >= measurementInterval)
  {
    measurmentPreviousMillis = measurmentCurrentMillis;
    takeAndTransmitMeasurments();
    SerialUSB.println();
  }
}

nmea_float_t OsaCarusele::altiduteCalc()
{

  currentTemp = (bme.readTemperature() + 274.15);

  currentPressure = bme.readPressure();
  //ssc.update();                                     //do testów
  //currentPressure = ssc.pressure()*Psi2Pascal;      //do testów
  calcCurrentAltitude = ((gasConst * currentTemp * (log(groundPressure / currentPressure))) / (standardGravity * airMolarMass));
  return calcCurrentAltitude;
}

void OsaCarusele::takeAndTransmitMeasurments()
{
  digitalWrite(ledPin, HIGH); ///// Niech miga gdy robi pomiar (gaśnie gdy skończy)

  takeMeasurments();

  measurementsFrameCreate();
  SerialUSB.print("FL ");
  SerialUSB.print(strlen(measurementsFrame));
  SerialUSB.print("\t ");
  SerialUSB.print(measurementsFrame);
  measurementsFrame.clear();

  radioFrameCreate();
  measurementsFrameFileWrite();
  measurementsFrameTransmit();
  measurementsFrame.clear();

  digitalWrite(ledPin, LOW); ////// kończy migać
}

void OsaCarusele::takeMeasurments()
{

  ambientTemp = bme.readTemperature();
  ambientPressure = bme.readPressure();
  ambientHumidity = bme.readHumidity();
  altiduteCalc();
  ssc.update();
  pipePressure = ssc.pressure() * Psi2Pascal;

  gpsHours = GPS.hour;
  gpsMinutes = GPS.minute;
  gpsSeconds = GPS.seconds;
  gpsMillis = GPS.milliseconds;
  gpsDay = GPS.day;
  gpsMonth = GPS.month;
  gpsYear = GPS.year;
  gpsFix = GPS.fix;
  gpsFixQuality = GPS.fixquality;
  gpsLatitude = GPS.latitude;
  gpsLat = GPS.lat;
  gpsLongitude = GPS.longitude;
  gpsLon = GPS.lon;
  gpsAltitude = GPS.altitude;
  gpsSat = GPS.satellites;
}

void OsaCarusele::measurementsFrameCreate()
{
  //altitude
  measurementsFrame.print("Current altitude: ");
  measurementsFrame.print(calcCurrentAltitude);
  measurementsFrame.print(" Initial altitude: ");
  measurementsFrame.print(initialAltitude);
  measurementsFrame.print(" Final altitude: ");
  measurementsFrame.print(finalAltitude);
  measurementsFrame.print(";");





  for (int i = 0; i < 5; i++)
  {
    measurementsFrame.print(probesDone[i]);
    measurementsFrame.print(";");
  }
  for (int i = 0; i < 5; i++)
  {
    measurementsFrame.print(samplesAltitudes[i][0], 1);
    measurementsFrame.print(";");
    measurementsFrame.print(samplesAltitudes[i][1], 1);
    measurementsFrame.print(";");
  }

  //sensors
  measurementsFrame.print(measurmentCurrentMillis / 1000.0F);
  measurementsFrame.print(";"); //Pipe Pressure [Pa]
  measurementsFrame.print(pipePressure);
  measurementsFrame.print(";"); //Ambient Pressure [Pa]
  measurementsFrame.print(ambientPressure);
  measurementsFrame.print(";"); //Ambient Temperature [*C]
  measurementsFrame.print(ambientTemp);
  measurementsFrame.print(";"); //Ambient Humidity [%]
  measurementsFrame.print(ambientHumidity);

  //GPS real time clock
  measurementsFrame.print(";"); //GPS Time [hh:mm:ss]
  if (gpsHours < 10)
  {
    measurementsFrame.print("0");
  }
  measurementsFrame.print(gpsHours, DEC);
  measurementsFrame.print(':');
  if (gpsMinutes < 10)
  {
    measurementsFrame.print("0");
  }
  measurementsFrame.print(gpsMinutes, DEC);
  measurementsFrame.print(':');
  if (gpsSeconds < 10)
  {
    measurementsFrame.print("0");
  }
  measurementsFrame.print(gpsSeconds, DEC);
  measurementsFrame.print('.');
  if (gpsMillis < 10)
  {
    measurementsFrame.print("00 ");
  }
  else if (gpsMillis > 9 && gpsMillis < 100)
  {
    measurementsFrame.print("0");
  }
  measurementsFrame.print("\t GD "); //GPS Date [dd/mm/yy]
  measurementsFrame.print(gpsDay, DEC);
  measurementsFrame.print('/');
  measurementsFrame.print(gpsMonth, DEC);
  measurementsFrame.print("/");
  measurementsFrame.print(gpsYear, DEC);

  //GPS fix & quality
  measurementsFrame.print("\t FX ");
  measurementsFrame.print((int)gpsFix); //GPS Fix: 0 - none / 1 - yes
  measurementsFrame.print("\t QA ");
  measurementsFrame.print((int)gpsFixQuality); //GPS Quality: 1 - 2D / 2 - 3D
  measurementsFrame.print(" Ps: ");
  measurementsFrame.print(isParachuteOpened());

  //GPS data
  if (gpsFix)
  {
    measurementsFrame.print("\t LC "); //GPS Location: Latitude, Longitude
    measurementsFrame.print(gpsLatitude, 4);
    measurementsFrame.print(gpsLat);
    measurementsFrame.print(", ");
    measurementsFrame.print(gpsLongitude, 4);
    measurementsFrame.print(gpsLon);
    measurementsFrame.print("\t AL ");
    measurementsFrame.print(gpsAltitude); //GPS Altidude [m]
    measurementsFrame.print("\t ST ");
    measurementsFrame.print((int)gpsSat); //GPS Satelite in Use
  }
  measurementsFrame.println();
}

void OsaCarusele::radioFrameCreate()
{

  //altitude
  ptr = bytes;
  measurementsFrame.print(calcCurrentAltitude);
  measurementsFrame.print(";");
  measurementsFrame.print(finalAltitude);
  measurementsFrame.print(";");
  measurementsFrame.print(programFaze);
  measurementsFrame.print(";");
  ptr = encode_f32(ptr, calcCurrentAltitude);
  ptr = encode_f32(ptr, finalAltitude);
  ptr = encode_uint8(ptr, programFaze);
  for (int i = 0; i < 5; i++)
  {
    measurementsFrame.print(probesDone[i]);  measurementsFrame.print(";");
    ptr = encode_uint8(ptr, probesDone[i]);
  }
  for (int i = 0; i < 5; i++)
  {
    
    measurementsFrame.print(samplesAltitudes[i][0]);
    measurementsFrame.print(";");
    measurementsFrame.print(samplesAltitudes[i][1]);
    measurementsFrame.print(";");

    ptr = encode_f32(ptr, samplesAltitudes[i][0]);
    ptr = encode_f32(ptr, samplesAltitudes[i][1]);

  }

  //sensors
  measurementsFrame.print(measurmentCurrentMillis / 1000.0F); //message.addRawFloat(measurmentCurrentMillis / 1000.0F);
  measurementsFrame.print(";");
  measurementsFrame.print(pipePressure); //message.addUnixtime(pipePressure);
  measurementsFrame.print(";");
  measurementsFrame.print(ambientPressure); //message.addUnixtime(ambientPressure);
  measurementsFrame.print(";");
  measurementsFrame.print(ambientTemp); //message.addTemperature(ambientTemp);
  measurementsFrame.print(";");
  measurementsFrame.print(ambientHumidity); //message.addHumidity(ambientHumidity);
  
  ptr = encode_f32(ptr, measurmentCurrentMillis/1000.0F);
  ptr = encode_uint32(ptr, pipePressure);
  ptr = encode_uint32(ptr, ambientPressure);
  ptr = encode_f32(ptr, ambientTemp);
  ptr = encode_f32(ptr, ambientHumidity);


 

  //GPS real time clock
  measurementsFrame.print(";");
  if (gpsHours < 10)
  {
    measurementsFrame.print("0");
  }
  measurementsFrame.print(gpsHours, DEC); //message.addUnixtime(gpsHours);
  measurementsFrame.print(':');
  
 

  if (gpsMinutes < 10)
  {
    measurementsFrame.print("0");
  }
  measurementsFrame.print(gpsMinutes, DEC); //message.addUnixtime(gpsMinutes);
  measurementsFrame.print(':');

  
  if (gpsSeconds < 10)
  {
    measurementsFrame.print("0");
  }
  measurementsFrame.print(gpsSeconds, DEC); //message.addUnixtime(gpsSeconds);
  measurementsFrame.print('.');
  
  if (gpsMillis < 10)
  {
    measurementsFrame.print("00");
  }
  else if (gpsMillis > 9 && gpsMillis < 100)
  {
    measurementsFrame.print("0");
  }

  measurementsFrame.print(";");
  measurementsFrame.print(gpsDay, DEC);
  measurementsFrame.print('/');
  measurementsFrame.print(gpsMonth, DEC);
  measurementsFrame.print("/");
  measurementsFrame.print(gpsYear, DEC);
  
  ptr = encode_uint8(ptr, gpsHours);
  ptr = encode_uint8(ptr, gpsMinutes);
  ptr = encode_uint8(ptr, gpsSeconds);

  ptr = encode_uint8(ptr, gpsDay);
  ptr = encode_uint8(ptr, gpsMonth);
  ptr = encode_uint16(ptr, gpsYear);


  //GPS fix & quality
  
  measurementsFrame.print(";");
  measurementsFrame.print((int)gpsFix); //message.addUint8(int(gpsFix)); //GPS Fix: 0 - none / 1 - yes
  measurementsFrame.print(";");
  measurementsFrame.print((int)gpsFixQuality); //message.addUint8(int(gpsFixQuality)); //GPS Quality: 1 - 2D / 2 - 3D
  measurementsFrame.print(";");
  measurementsFrame.print(isParachuteOpened());

  ptr = encode_uint8(ptr, ((int)gpsFix));
  ptr = encode_uint8(ptr, ((int)gpsFixQuality));

  ptr = encode_uint8(ptr, isParachuteOpened());

  //GPS data
  
  if (gpsFix)
  {
    measurementsFrame.print(";");            //GPS Location: Latitude, Longitude
    measurementsFrame.print(gpsLatitude, 4); //message.addLatLng(gpsLatitude,gpsLongitude);
    measurementsFrame.print(gpsLat);
    measurementsFrame.print(",");
    measurementsFrame.print(gpsLongitude, 4);
    measurementsFrame.print(gpsLon);
    measurementsFrame.print(";");
    measurementsFrame.print(gpsAltitude); // message.addUint16(gpsAltitude);//GPS Altidude [m]
    measurementsFrame.print(";");
    measurementsFrame.print((int)gpsSat); //message.addUint8((int)gpsSat); //GPS Satelite in Use
  
   
   ptr = encode_f32(ptr, gpsLatitude);
   ptr = encode_char(ptr, gpsLat);
   ptr = encode_f32(ptr, gpsLongitude);
   ptr = encode_char(ptr, gpsLon);
   ptr = encode_f32(ptr, gpsAltitude);
   ptr = encode_uint8(ptr, ((int)gpsSat));

  }
  measurementsFrame.println();
}

void OsaCarusele::measurementsFrameTransmit()
{
  /*//  send frame via radio
  while (not radio.transmit(bytes)
  {
    radio.transmit(bytes);
  }
  */
  while (not radio.transmit(bytes, 100))
  {
    radio.transmit(bytes, 100);
  }
}

void OsaCarusele::measurementsFrameFileWrite()
{
  // open the file. note that only one file can be open at a time,
  // so you have to close this one before opening another.
  measurementsFile = SD.open(measurementsFileName, FILE_WRITE);

  // if the file is available, write to it:
  if (measurementsFile)
  {
    measurementsFile.print(measurementsFrame);
    measurementsFile.close();
  }
  // if the file isn't open, pop up an error:
  else
  {
    SerialUSB.println("error opening datalog.txt");
  }
}

//---------------encoder-----------------------
uint8_t *OsaCarusele::encode_bytes(uint8_t *ptr, void *bytes, uint16_t size)
{
  memcpy(ptr, bytes, size);
  return ptr + size;
}

uint8_t *OsaCarusele::decode_bytes(uint8_t *ptr, void *bytes, uint16_t size)
{
  memcpy(bytes, ptr, size);
  return ptr + size;
}

uint8_t *OsaCarusele::encode_uint8(uint8_t *ptr, uint8_t value)
{
  return encode_bytes(ptr, &value, sizeof(uint8_t));
}

uint8_t *OsaCarusele::encode_uint16(uint8_t *ptr, uint16_t value)
{
  return encode_bytes(ptr, &value, sizeof(uint16_t));
}

uint8_t *OsaCarusele::encode_uint32(uint8_t *ptr, uint32_t value)
{
  return encode_bytes(ptr, &value, sizeof(uint32_t));
}

uint8_t *OsaCarusele::encode_f32(uint8_t *ptr, float value)
{
  return encode_bytes(ptr, &value, sizeof(float));
}

uint8_t *OsaCarusele::encode_char(uint8_t *ptr, char value)
{
  return encode_bytes(ptr, &value, sizeof(char));
}

uint8_t *OsaCarusele::decode_uint8(uint8_t *ptr, uint8_t *value)
{
  return decode_bytes(ptr, value, sizeof(uint8_t));
}

uint8_t *OsaCarusele::decode_uint16(uint8_t *ptr, uint16_t *value)
{
  return decode_bytes(ptr, value, sizeof(uint16_t));
}

uint8_t *OsaCarusele::decode_uint32(uint8_t *ptr, uint32_t *value)
{
  return decode_bytes(ptr, value, sizeof(uint32_t));
}

uint8_t *OsaCarusele::decode_f32(uint8_t *ptr, float *value)
{
  return decode_bytes(ptr, value, sizeof(float));
}

uint8_t *OsaCarusele::decode_char(uint8_t *ptr, char *value)
{
  return decode_bytes(ptr, value, sizeof(char));
}